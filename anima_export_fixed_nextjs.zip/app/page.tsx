// If any child uses browser-only APIs, convert those specific components to 'use client'
import { HomeDesktop } from '@/screens/HomeDesktop/HomeDesktop';

export default function Page() {
  return <HomeDesktop />;
}
