# Jersey Elite Coatings - Professional Epoxy Flooring Website

A modern, professional website for Jersey Elite Coatings built with Next.js, TypeScript, and Tailwind CSS.

## 🚀 Quick Start

### Prerequisites
- Node.js 18.0 or later
- npm or yarn

### Installation & Development
```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Open http://localhost:3000
```

### Production Build
```bash
# Build for production
npm run build

# Start production server
npm start
```

## 🌐 Deployment

### Vercel (Recommended)
1. Push code to GitHub
2. Connect repository to Vercel
3. Deploy automatically

### Other Platforms
- **Netlify**: Connect GitHub repo for auto-deploy
- **AWS Amplify**: Connect repository
- **Static Hosting**: Run `npm run build` and upload `.next` folder

## 📁 Project Structure
```
├── app/                    # Next.js App Router
│   ├── globals.css        # Global styles & CSS variables
│   ├── layout.tsx         # Root layout with fonts & metadata
│   └── page.tsx          # Home page
├── components/            # React components
│   └── HomeDesktop/      # Main page sections
├── next.config.js        # Next.js configuration
├── tailwind.config.js    # Tailwind CSS configuration
└── tsconfig.json         # TypeScript configuration
```

## ✨ Features
- **Modern Design**: Professional, sleek interface
- **Fully Responsive**: Works on all devices
- **SEO Optimized**: Proper metadata and structure
- **Performance**: Optimized images and code splitting
- **TypeScript**: Full type safety
- **Tailwind CSS**: Utility-first styling

## 🎨 Customization
- **Colors**: Edit CSS variables in `app/globals.css`
- **Content**: Modify components in `components/HomeDesktop/sections/`
- **Styling**: Update `tailwind.config.js`
- **Metadata**: Edit `app/layout.tsx`

## 🔧 Configuration
- **ESLint**: Configured for Next.js
- **TypeScript**: Strict mode enabled
- **Fonts**: Google Fonts (Inter & Gelasio)
- **Images**: Optimized for static export

## 📞 Support
For technical support or customization requests, please contact the development team.

---
Built with ❤️ for Jersey Elite Coatings
