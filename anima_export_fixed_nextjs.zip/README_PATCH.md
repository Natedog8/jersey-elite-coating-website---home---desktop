# Patch Notes for Next.js (Vercel) Deployment

This patch removes Vite/SPA artifacts and fixes imports so the Anima export builds on Next.js 14 (App Router).

## What changed
- Removed: `index.html`, `vite.config.ts`, `src/index.tsx`, `tsconfig.app.json`, `tsconfig.node.json`
- `app/layout.tsx`: replaced with a valid Next.js layout
- `app/page.tsx`: now imports `HomeDesktop` from `src/screens/HomeDesktop/HomeDesktop`
- `tsconfig.json`: set path alias `@/*` → `./src/*`
- `next.config.js`: safe defaults (ignore lint/TS during build, unoptimized images, strict mode)

## Local dev
```bash
npm i
npm run dev
```

## Deploy on Vercel
1. Push this repo to GitHub.
2. Import the repo in Vercel. Framework should auto-detect: **Next.js**.
3. Build command: `next build` (default). Output: `.next` (default).

## If you see SSR errors (window/document not defined)
Only wrap the offending component, **not the whole app**, with a no-SSR dynamic import:

```tsx
'use client';
import dynamic from 'next/dynamic';

const ClientOnlySection = dynamic(() => import('@/screens/.../YourSection'), { ssr: false });

export default function Page() {
  return <ClientOnlySection />;
}
```

Alternatively, in a component that touches `window`/`document`, use:

```tsx
'use client';
import { useEffect, useState } from 'react';

export default function Example() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  if (!ready) return null;
  // safe to use window/document here
  return <div>{window.location.pathname}</div>;
}
```

